import React,{useState,useEffect} from 'react'
import axios from 'axios';

export const Posts = (props) => {
    const [posts, setPosts] = useState([]);
    useEffect(() => {
        axios("https://jsonplaceholder.typicode.com/posts", {
            headers: {
                "Accept": "application/json"
            }
        }).then(res => setPosts(res.data));
    }, []);
    return(
        <div>
           <h1> Posts </h1>
           <ul>
               {posts.map(p=><li key={p.id}>{p.title}</li>)}
           </ul>
        </div>
    )
}

export default Posts