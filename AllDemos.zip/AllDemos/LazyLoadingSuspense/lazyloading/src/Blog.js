import React, { Suspense } from 'react';
//import Posts from './Posts'
const Posts = React.lazy(() => import('./Posts'));

export const Blog = (props) => {
    return (
        <Suspense fallback={<div>Loading...</div>}>
            <Posts />          
        </Suspense>

    )
}

export default Blog;