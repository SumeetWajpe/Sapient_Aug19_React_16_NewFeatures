import React, { Component } from 'react';

const LikesContext = React.createContext();

export class MyProvider extends Component {
    state = {
        likes: 100
    }

    render() {
        return (
            <LikesContext.Provider value={{
                state: this.state,
                incrementLikes: () => this.setState({
                    likes: this.state.likes + 1
                })
            }}>
                {this.props.children}
            </LikesContext.Provider>

        )
    }
}

export class ShoppingCart extends Component {
    render() {
        return (
            <MyProvider>
                <div className="container">
                    <h1>Shopping Cart</h1>
                    <Product />
                </div>
            </MyProvider>
        )
    }
}

export class Product extends Component {
    render() {
        return (
            <div>
                <h1>Product</h1>
                <Likes likes={this.props.likes} />
            </div>
        )
    }
}

export class Likes extends Component {
    render() {
        return (
            <div >


                <LikesContext.Consumer>
                    {(context) => (
                        <div>
                            <h1>Likes</h1>
                            <button className="btn btn-primary" onClick={context.incrementLikes}>
                                {context.state.likes}
                                <span className="glyphicon glyphicon-thumbs-up">

                                </span>
                            </button>          </div>
                    )}
                </LikesContext.Consumer>


            </div>
        )
    }
}

export default ShoppingCart;